import { useState } from 'react';
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';
import { IoMdAdd } from "react-icons/io";
import 'bootstrap/dist/css/bootstrap.min.css'; 
import { MdOutlineCancelPresentation } from "react-icons/md"

function UserForm() {
  const [show, setShow] = useState(false);
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [score, setScore] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [tags, setTags] = useState('');
  const [date, setDate] = useState('');
  const [loading, setLoading] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await axios.post('http://localhost:3000/submit-form', { name, company, score, phone, location, tags, date });
      alert('User data inserted successfully');
      handleClose();
    } catch (err) {
      console.error(err);
      alert('Failed to insert user data: ' + err.message);
    } finally {
      setLoading(false);
    }
  };


  return (
    <div>
      <Button className='Add-leads-button' variant="primary" onClick={handleShow}>
      <IoMdAdd /> Add leads
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header className='header'>
          <div className='headercancle' onClick={handleClose} style={{ cursor: 'pointer' }}><MdOutlineCancelPresentation /></div>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Name"
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                required 
                autoFocus
              />
            </Form.Group>
            <Form.Group
              className="mb-3" controlId="exampleForm.ControlInput2" >
              <Form.Label>Company</Form.Label>
              <Form.Control 
              type='text'
              placeholder='Company'
              value={company} 
              onChange={(e) => setCompany(e.target.value)}
              required 
              autoFocus
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput3">
              <Form.Label>Lead Score</Form.Label>
              <Form.Control
                type="number"
                placeholder="Leadscore"
                value={score} 
                onChange={(e) => setScore(e.target.value)} 
                required 
                   min="0"
                max="100"
                autoFocus
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput4" >
              <Form.Label>Phone</Form.Label>
              <Form.Control 
              type='number'
              placeholder='Phone'
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required 
                  pattern="[0-9]{10}"
                title="Please enter a valid 10-digit phone number"
              autoFocus
              />
            </Form.Group>
           <Form.Group className="mb-3" controlId="exampleForm.ControlInput5">
              <Form.Label>Location</Form.Label>
              <Form.Control
                type="text"
                placeholder="Location"
                value={location} 
                onChange={(e) => setLocation(e.target.value)} 
                required 
                autoFocus
              />
            </Form.Group>
            <Form.Group
              className="mb-3" controlId="exampleForm.ControlInput6" >
              <Form.Label>Tags</Form.Label>
              <Form.Control 
              type='text'
              placeholder='Tags'
              value={tags} 
              onChange={(e) => setTags(e.target.value)}
              required 
              autoFocus
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput7">
              <Form.Label>Create Date</Form.Label>
              <Form.Control
                type="date"
                placeholder="Createdate"
                value={date} 
                onChange={(e) => setDate(e.target.value)} 
                required 
                autoFocus
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
              <Button variant="secondary" onClick={handleClose} disabled={loading}>
                Close
              </Button>
              <Button variant="primary" onClick={handleSubmit} disabled={loading}>
                {loading ? 'Adding...' : 'Add Lead'}
              </Button>
            </Modal.Footer>
      </Modal>
    </div>
  );
}

export default UserForm;