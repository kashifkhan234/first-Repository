import React from 'react';
import { AiOutlineDashboard, AiFillAppstore } from 'react-icons/ai'
import { RiLayoutColumnLine, RiBriefcaseLine } from 'react-icons/ri'
import { FaRegUserCircle } from 'react-icons/fa'
import { PiRocket } from 'react-icons/pi'
import { LuPencilRuler } from 'react-icons/lu'
import { LiaPagerSolid, LiaFlaskSolid, LiaNewspaperSolid, LiaTableSolid, LiaChartPieSolid, LiaFonticons, LiaFolderPlusSolid } from 'react-icons/lia'
import { CiMap } from 'react-icons/ci'
import { MdOutlineNavigateNext } from 'react-icons/md'
import Velzon from './Images/Velzon.png'

const Sidebar = () => {
  return (
    <div className="sidebar">
        <div>
          <img className='velzon-logo' src={Velzon} alt=''/>
        </div>
        <div className='sidebar-Menu'>MENU</div>
      <ul>
        <li className='Sidebar-list'><a href="/"><AiOutlineDashboard />Dashboard</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/App"><AiFillAppstore />App</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/Layouts"><RiLayoutColumnLine />Layouts</a><button className='layout-button'>Hot</button></li>
        </ul>
        <div className='sidebar-Menu'>PAGES</div>
        <ul>
        <li className='Sidebar-list'><a href="/Authentication"><FaRegUserCircle />Authentication</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/Pages"><LiaPagerSolid />Pages</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/Landing"> <PiRocket />Landing</a><MdOutlineNavigateNext /></li>
      </ul>
      <div className='sidebar-Menu'>COMPONENTS</div>
      <ul>
      <li className='Sidebar-list'><a href="/Base UI"> <LuPencilRuler />Base UI</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/Advance UI"> <RiBriefcaseLine />Advance UI</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/Windgets"> <LiaFlaskSolid />Windgets</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/Forms"> <LiaNewspaperSolid />Forms</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/Tables"> <LiaTableSolid />Tables</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/Charts"> <LiaChartPieSolid />Charts</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/Icons"> <LiaFonticons />Icons</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/Maps"> <CiMap />Maps</a><MdOutlineNavigateNext /></li>
        <li className='Sidebar-list'><a href="/Multi Level"> <LiaFolderPlusSolid />Multi Level</a><MdOutlineNavigateNext /></li>

      </ul>
    </div>
  );
};

export default Sidebar;
