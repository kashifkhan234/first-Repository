import React from 'react';
import './App.css';
import DataList from './Details';
import Sidebar from './Sidebar';
function App() {
  return (
    <div className="App">
    <div className="content">
  <h3>Leads</h3>
  </div>
  <div className='homepage'>
  <div className='react-pro-sidebar'><Sidebar/></div>
  <div><DataList/></div>
  </div>
    </div>
  );
}

export default App;

