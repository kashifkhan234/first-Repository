
import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import { MdEdit, MdDelete } from "react-icons/md";
import { IoFilter, IoSettingsOutline, IoSearch } from "react-icons/io5";
import { IoIosEye } from "react-icons/io";
import { RiDeleteBin6Line } from "react-icons/ri";
import Datatable from "react-data-table-component";
import ScrollToTop from 'react-scroll-to-top';
import UserForm from './UserForm';
import Select from 'react-select';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Modal, Button, Form, FormControl } from 'react-bootstrap';


const DataList = () => {
  const [data, setData] = useState([]);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);
  const [showFilters, setShowFilters] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [filters, setFilters] = useState({
    Name: '',
    Company: '',
    Leadscore: '',
    Phone: '',
    Location: '',
    Tags: '',
    Createdate: ''
  });
  const [formData, setFormData] = useState({
    Name: '',
    Company: '',
    Leadscore: '',
    Phone: '',
    Location: '',
    Tags: '',
    Createdate: ''
  });

  const fetchData = async () => {
    try {
      const response = await axios.get('http://localhost:3000/details');
      setData(response.data);
      setFilterData(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
      alert('Failed to fetch data. Please try again later.');
    }
  };

  const handleEdit = (item) => {
    setShowEditModal(item.id);
    setFormData({
      Name: item.Name,
      Company: item.Company,
      Leadscore: item.Leadscore,
      Phone: item.Phone,
      Location: item.Location,
      Tags: item.Tags,
      Createdate: item.Createdate
    });
  };

  const handleUpdate = async (id) => {
    try {
      await axios.put(`http://localhost:3000/update-data/${id}`, formData);
      setData(data.map(item => (item.id === id ? { ...item, ...formData } : item)));
      setShowEditModal(null);
    } catch (error) {
      console.error('Error updating data:', error);
    }
  };

  const handleDelete = async (row) => {
    if (window.confirm("Are you sure you want to delete this record?")) {
      try {
        await axios.delete(`http://localhost:3000/delete-data/${row.id}`);
        fetchData();
      } catch (error) {
        console.error('Error deleting data:', error);
        alert('Failed to delete data. Please try again later.');
      }
    }
  };

  const handleView = (item) => {
    setShowViewModal(item);
  };

  const handleFilterChange = (selectedOption, actionMeta) => {
    setFilters({
      ...filters,
      [actionMeta.name]: selectedOption ? selectedOption.value : ''
    });
  };

  const applyFilters = () => {
    let result = data;
    Object.keys(filters).forEach(key => {
      if (filters[key]) {
        result = result.filter(item => item[key].toString().toLowerCase().includes(filters[key].toLowerCase()));
      }
    });
    setFilterData(result);
    setShowFilters(false); 
  };

  const columns = useMemo(() => [
    { name: 'Name', selector: row => row.Name, sortable: true },
    { name: 'Company', selector: row => row.Company, sortable: true },
    { name: 'Leadscore', selector: row => row.Leadscore, sortable: true },
    { name: 'Phone', selector: row => row.Phone, sortable: true },
    { name: 'Location', selector: row => row.Location, sortable: true },
    { name: 'Tags', selector: row => row.Tags, sortable: true },
    { name: 'Createdate', selector: row => row.Createdate, sortable: true },
    {
      name: 'Action',
      cell: row => (
        <div className='datalist button'>
          <IoIosEye className='View-button' onClick={() => handleView(row)} />
          <MdEdit onClick={() => handleEdit(row)} />
          <MdDelete onClick={() => handleDelete(row)} />
        </div>
      ),
      sortable: false,
    }
  ], []);

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    const result = data.filter(item => item.Name.toLowerCase().includes(search.toLowerCase()));
    setFilterData(result);
  }, [search, data]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  const nameOptions = useMemo(() => [...new Set(data.map(item => item.Name))].map(name => ({ value: name, label: name })), [data]);
  const companyOptions = useMemo(() => [...new Set(data.map(item => item.Company))].map(company => ({ value: company, label: company })), [data]);
  const leadscoreOptions = useMemo(() => [...new Set(data.map(item => item.Leadscore))].map(leadscore => ({ value: leadscore, label: leadscore })), [data]);
  const phoneOptions = useMemo(() => [...new Set(data.map(item => item.Phone))].map(phone => ({ value: phone, label: phone })), [data]);
  const locationOptions = useMemo(() => [...new Set(data.map(item => item.Location))].map(location => ({ value: location, label: location })), [data]);
  const tagsOptions = useMemo(() => [...new Set(data.map(item => item.Tags))].map(tags => ({ value: tags, label: tags })), [data]);
  const createdateOptions = useMemo(() => [...new Set(data.map(item => item.Createdate))].map(createdate => ({ value: createdate, label: createdate })), [data]);

  const handleBulkDelete = async () => {
    if (selectedRows.length === 0) {
      alert('Please select at least one record to delete.');
      return;
    }

    if (window.confirm("Are you sure you want to delete selected records?")) {
      try {
        const idsToDelete = selectedRows.map(row => row.id);
        await axios.delete('http://localhost:3000/delete-data', { data: { ids: idsToDelete } });
        fetchData();
        setSelectedRows([]);
      } catch (error) {
        console.error('Error deleting data:', error);
        alert('Failed to delete data. Please try again later.');
      }
    }
  };

  return (
    <div className='table-content'>
      <div className='table-header'>
      <div className='search-bar-container'>
      <div className='search-bar-wrapper'>
        <IoSearch className='search-icon' />
        <input 
          className='search-bar'
          type='text'
          placeholder='Search for...'
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>
    </div>
        <div className='filter&add-button'>
        <button className='bulk-delete-button' onClick={handleBulkDelete} disabled={selectedRows.length === 0}><RiDeleteBin6Line /></button>
          <Button className='filter-button' onClick={() => setShowFilters(true)}>
            <IoFilter /> Filters
          </Button>
          <UserForm />
          <button className='settings-button'><IoSettingsOutline /></button>
        </div>
      </div>

      <Modal show={showFilters} onHide={() => setShowFilters(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Filters</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Select
            name="Name"
            options={nameOptions}
            placeholder="Name"
            isClearable
            onChange={handleFilterChange}
          />
          <Select
            name="Company"
            options={companyOptions}
            placeholder="Company"
            isClearable
            onChange={handleFilterChange}
          />
          <Select
            name="Leadscore"
            options={leadscoreOptions}
            placeholder="Leadscore"
            isClearable
            onChange={handleFilterChange}
          />
          <Select
            name="Phone"
            options={phoneOptions}
            placeholder="Phone"
            isClearable
            onChange={handleFilterChange}
          />
          <Select
            name="Location"
            options={locationOptions}
            placeholder="Location"
            isClearable
            onChange={handleFilterChange}
          />
          <Select
            name="Tags"
            options={tagsOptions}
            placeholder="Tags"
            isClearable
            onChange={handleFilterChange}
          />
          <Select
            name="Createdate"
            options={createdateOptions}
            placeholder="Createdate"
            isClearable
            onChange={handleFilterChange}
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowFilters(false)}>
            Close
          </Button>
          <Button variant="primary" onClick={applyFilters}>
            Apply Filters
          </Button>
        </Modal.Footer>
      </Modal>
      <div className='table-data'>
        <Datatable 
          columns={columns}
          data={filterData}
          pagination
          selectableRows
          highlightOnHover
          onSelectedRowsChange={({ selectedRows }) => setSelectedRows(selectedRows)}
          selectableRowsHighlight
        />
      </div>
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Data</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={(e) => { e.preventDefault(); handleUpdate(showEditModal); }}>
          <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
            <Form.Label className='edit-label'>
              Name
              <FormControl type='text' name='Name' value={formData.Name} onChange={handleChange} />
            </Form.Label>
            </Form.Group>
              <Form.Group className="mb-3" controlId="exampleForm.ControlInput2">
            <Form.Label className='edit-label'>
              Company
              <FormControl type='text' name='Company' value={formData.Company} onChange={handleChange} />
            </Form.Label>
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput3">
            <Form.Label className='edit-label'>
              Leadscore
              <FormControl type='text' name='Leadscore' value={formData.Leadscore} onChange={handleChange} />
            </Form.Label>
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput4">
            <Form.Label className='edit-label'>
              Phone
              <FormControl type='text' name='Phone' value={formData.Phone} onChange={handleChange} />
            </Form.Label>
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput5">
            <Form.Label className='edit-label'>
              Location
              <FormControl type='text' name='Location' value={formData.Location} onChange={handleChange} />
            </Form.Label>
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput6">
            <Form.Label className='edit-label'>
              Tags
              <FormControl type='text' name='Tags' value={formData.Tags} onChange={handleChange} />
            </Form.Label>
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput7">
            <Form.Label className='edit-label'>
              Createdate
              <FormControl type='text' name='Createdate' value={formData.Createdate} onChange={handleChange} />
            </Form.Label>
            </Form.Group>
            <Modal.Footer>
              <Button variant='secondary' onClick={() => setShowEditModal(false)}>CANCEL</Button>
              <Button type='submit' variant='primary'>UPDATE</Button>
              </Modal.Footer>
          </Form>
        </Modal.Body>
      </Modal>

<Modal show={showViewModal} onHide={() => setShowViewModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>View Data</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {showViewModal && (
            <div>
              <p><strong>Name:</strong> {showViewModal.Name}</p>
              <p><strong>Company:</strong> {showViewModal.Company}</p>
              <p><strong>Leadscore:</strong> {showViewModal.Leadscore}</p>
              <p><strong>Phone:</strong> {showViewModal.Phone}</p>
              <p><strong>Location:</strong> {showViewModal.Location}</p>
              <p><strong>Tags:</strong> {showViewModal.Tags}</p>
              <p><strong>Createdate:</strong> {showViewModal.Createdate}</p>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant='secondary' onClick={() => setShowViewModal(false)}>CLOSE</Button>
        </Modal.Footer>
      </Modal>

      <ScrollToTop smooth />
    </div>
  );
};

export default DataList;

