
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const cors = require('cors');
const PORT = 3000;

const app = express();

app.use(bodyParser.json());
app.use(cors());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'velzonnewdb'
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to the database');
});

app.post('/submit-form', async (req, res) => {
  const { name, company, score, phone, location, tags, date } = req.body;
  const sql = 'INSERT INTO datatable (Name, Company, leadscore, Phone, Location, Tags, Createdate) VALUES (?, ?, ?, ?, ?, ?, ?)';
  db.query(sql, [name, company, score, phone, location, tags, date], (err, result) => {
    if (err) throw err;
    res.send('User data inserted successfully');
  });
});

app.get('/Details', (req, res) => {
  const query = 'SELECT * FROM `datatable`';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving data:', err);
      res.status(500).send('Failed to retrieve data');
      return;
    }
    res.json(results);
  });
});
app.put('/update-data/:id', (req, res) => {
  const { id } = req.params;
  const { name, company, score, phone, location, tags, date } = req.body;
  const query = 'UPDATE datatable SET Name = ?, Company = ?, leadscore = ?, Phone = ?, Location = ?, Tags = ?, Createdate = ? WHERE id = ?';
  db.query(query, [name, company, score, phone, location, tags, date, id], (err, result) => {
    if (err) {
      console.error('Error updating data:', err);
      res.status(500).send('Failed to update data');
      return;
    }
    res.send('Data updated successfully');
  });
});

app.delete('/delete-data/:id', (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM `datatable` WHERE id = ?';

  db.query(query, [id], (err, result) => {
    if (err) {
      console.error('Error deleting data:', err);
      res.status(500).send('Failed to delete data');
      return;
    }
    res.send('Data deleted successfully');
  });
});


app.delete('/delete-data', (req, res) => {
  const idsToDelete = req.body.ids;
  const query = `DELETE FROM datatable WHERE id IN (?)`;

  db.query(query, [idsToDelete], (err, result) => {
    if (err) {
      console.error('Error deleting data:', err);
      res.status(500).send('Failed to delete data');
      return;
    }
    res.send('Data deleted successfully');
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
